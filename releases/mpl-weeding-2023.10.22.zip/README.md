# mpl-weeding-firefox
Madison Public Library's tool for weeding catalog items
